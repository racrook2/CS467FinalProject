# CS467 Final Project

## Instructions
Use the following commands to get this up and running
```bash
git clone https://github.com/racrook2/CS467FinalProject_webpage.git
cd CS467FinalProject_webpage
npm install
bower install
grunt compass
grunt uglify
grunt
```

You can leave this command running in the background for livereloading:

```bash
grunt
```