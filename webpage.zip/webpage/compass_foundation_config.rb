# Find out more at http://compass-style.org/help/documentation/configuration-reference/
css_dir = 'public/foundation6_lib/css'
sass_dir = 'public/foundation6_lib/scss'
output_style = :compressed #change this to :nested if you want readable CSS
